<?php

require_once 'vendor/autoload.php';
use App\Models\Customer;
use App\Models\MongoDB;

if(isset($_POST['submit'])){
  $title = $_POST['title'];
  $fname = $_POST['fname'];
  $sname = $_POST['sname'];
  $mobile = $_POST['mobile'];
  $email = $_POST['email'];
  $homeaddress = $_POST['homeaddress'];
  $shippingaddress = $_POST['shippingaddress'];
  $town = $_POST['town'];
  $country = $_POST['country'];
  $eircode = $_POST['eircode'];

  $c = new Customer($title,$fname,$sname,$mobile,$email,$homeaddress,$shippingaddress,$town,$country,$eircode);

  $connection = new MongoDB;

  $result = $connection->add_customer($c);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Phone Store</title>
  <link rel="stylesheet" href="./css/bootstrap.css">

</head>

<body>
  <div class="container-scroller">
    <!-- partial:../../partials/_navbar.html -->
   
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial -->
      <div class="main-panel">        
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-9 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Customer  form</h4>
                  <p class="card-description">
                  </p>
                  <form class="forms-sample" method="post" action="add_customer.php">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Title</label>
                      <input type="text" class="form-control" id="title" name="title" placeholder="Title" required>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">First Name
</label>
                      <input type="text" class="form-control" id="fname" name="fname" placeholder="name" required>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Surname</label>
                      <input type="text" class="form-control" id="sname" name="sname" placeholder="Surname" required>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputConfirmPassword1">Mobile</label>
                      <input type="text" class="form-control" id="mobile" name="mobile" placeholder="mobile" required>
                    </div>
                     <div class="form-group">
                      <label for="exampleInputConfirmPassword1">Email Address
</label>
                      <input type="text" class="form-control" id="email" name="email" placeholder="email" required>
                    </div>
                     <div class="form-group">
                      <label for="exampleInputConfirmPassword1">Home Address </label>
                      <input type="text" class="form-control" id="homeaddress" name="homeaddress" required placeholder="Home Address ID">
                    </div>
                     <div class="form-group">
                      <label for="exampleInputConfirmPassword1">Shipping Address</label>
                      <input type="text" class="form-control" id="shippingaddress" name="shippingaddress" required placeholder="Shipping Address">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputConfirmPassword1">Town</label>
                      <input type="text" class="form-control" id="town" name="town" required placeholder="Town">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputConfirmPassword1">Country</label>
                      <input type="text" class="form-control" id="country" name="country" required placeholder="Country">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputConfirmPassword1">Eircode</label>
                      <input type="text" class="form-control" id="eircode" name="eircode" required placeholder="Eircode">
                    </div>
                    <button type="submit" class="btn btn-primary me-2" name="submit"><a href="customer_data.php">Submit</button>
                    <button class="btn btn-light">Cancel</button>
                  </form>
                </div>
              </div>
            </div>
            
          </div>
        </div>   
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
</body>

</html>
