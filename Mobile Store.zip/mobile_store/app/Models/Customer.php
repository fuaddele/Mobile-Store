<?php

namespace App\Models;
class Customer
{
    // private $id;
    private $title;
    private $firstName;
    private $surname;
    private $mobile;
    private $email;
    private $homeaddress;
    private $shippingaddress;
    private $town;
    private $country;
    private $eircode;

    public function __construct($title, $firstName, $surname, $mobile, $email, $homeaddress, $shippingaddress, $town, $country, $eircode= null)
    {
        // $this->id = $id;
        $this->title = $title;
        $this->firstName = $firstName;
        $this->surname = $surname;
        $this->mobile = $mobile;
        $this->email = $email;
        $this->homeaddress = $homeaddress;
        $this->shippingaddress = $shippingaddress;
        $this->town = $town;
        $this->country = $country;
        $this->eircode = $eircode;
    }

    // public function getId()
    // {
    //     return $this->id;
    // }

    public function getTitle()
    {
        return $this->title;
    }

    public function getFirstName()
    {
        return $this->firstName;
    }

    public function getSurname()
    {
        return $this->surname;
    }

    public function getMobile()
    {
        return $this->mobile;
    }

    public function getEmail()
    {
        return $this->email;
    }

    public function getAddressLine1()
    {
        return $this->homeaddress;
    }

    public function getAddressLine2()
    {
        return $this->shippingaddress;
    }

    public function getTown()
    {
        return $this->town;
    }

    public function getCountry()
    {
        return $this->country;
    }

    public function getEircode()
    {
        return $this->eircode;
    }

    
}
