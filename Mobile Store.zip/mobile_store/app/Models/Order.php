<?php

namespace App\Models;

// require_once 'vendor/autoload.php';
class Order
{
    private $customer;
    private $items;

    public function __construct($customer, $items)
    {
        $this->customer = $customer;
        $this->items = $items;
    }

    public function getCustomer(){
        return $this->customer;
    }

    public function getItems(){
        return $this->items;
    }
    
        
    
}