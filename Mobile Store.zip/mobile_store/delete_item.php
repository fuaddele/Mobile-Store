<?php


require_once 'vendor/autoload.php';
// use App\Models\Customer;
use App\Models\MongoDB;


$id = $_POST['id'];
$connection = new MongoDB;


$check = $connection->deleteitem($id);

header("Refresh: 2; url=item_data.php");


?>