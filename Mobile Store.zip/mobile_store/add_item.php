<?php

require_once 'vendor/autoload.php';
use App\Models\Item;
use App\Models\MongoDB;

if(isset($_POST['submit'])){
  $manufacturer = $_POST['manufacturer'];
  $model = $_POST['model'];
  $price = $_POST['price'];

  $i = new Item($manufacturer,$model,$price);

  $connection = new MongoDB;

  $result = $connection->add_item($i);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Phone Store</title>
  <link rel="stylesheet" href="./css/bootstrap.css">


</head>

<body>
  <div class="container-scroller">
    <!-- partial:../../partials/_navbar.html -->
    
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial -->
      <div class="main-panel">        
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-9 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Item  form</h4>
                  <p class="card-description">
                  </p>
                  <form class="forms-sample" method="post" action="add_item.php">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Manufacturer</label>
                      <input type="text" class="form-control" id="manufacturer" name="manufacturer" placeholder="manufacturer" required>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Model
</label>
                      <input type="text" class="form-control" id="model" name="model" placeholder="model" required>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Price</label>
                      <input type="text" class="form-control" id="price" name="price" placeholder="price" required>
                    </div>
                    <button type="submit" class="btn btn-primary me-2" name="submit"><a href="item_data.php">Submit</button>
                    <button class="btn btn-light">Cancel</button>
                  </form>
                </div>
              </div>
            </div>
            
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
       
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
</body>

</html>
