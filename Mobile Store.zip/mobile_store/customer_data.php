<?php


require_once 'vendor/autoload.php';
// use App\Models\Customer;
use App\Models\MongoDB;

$connection = new MongoDB;

$customers = $connection->allcustomers();

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Phone Store</title>
  <link rel="stylesheet" href="./css/bootstrap.css">

<body>
  <div class="container-scroller">
    
    <div class="container-fluid page-body-wrapper">
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">

            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Customer Table</h4>

                  <p class="card-description">
                  </p>
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>
                            CustomerID
                          </th>
                          <th>
                            Title </th>
                          <th>
                            First Name
                          </th>
                          <th>
                            Surname

                          </th>
                          <th>
                            Mobile

                          </th>
                         
                          <th>
                            Email Address

                          </th>
                          <th>
                            Home Address ID
                          </th>
                          <th>
                            Shipping Address ID
                          </th>
                          <th>
                            Town
                          </th>
                          <th>
                            Country
                          </th>
                          <th>
                            Eircode
                          </th>
                          <th>
                            Action
                          </th>

                        </tr>

                      </thead>
                      <tbody>
                        <?php 
                          foreach($customers as $customer){
                        ?>
                        <tr>

                          <td>
                            <?php echo $customer['_id'] ?>
                          </td>
                          <td>
                            <?php echo $customer['title'] ?>
                          </td>
                          <td>
                            <?php echo $customer['firstName'] ?>
                          </td>
                          <td>
                            <?php echo $customer['surname'] ?>
                          </td>
                          <td>
                            <?php echo $customer['mobile'] ?>
                          </td>
                          <td>
                            <?php echo $customer['email'] ?>
                          </td>
                          <td>
                            <?php echo $customer['homeaddress'] ?>
                          </td>
                          <td>
                            <?php echo $customer['shippingaddress'] ?>
                          </td>
                          <td>
                            <?php echo $customer['town'] ?>
                          </td>
                          <td>
                            <?php echo $customer['country'] ?>
                          </td>
                          <td>
                            <?php echo $customer['eircode'] ?>
                          </td>
                          <td>
                            <form action="delete_customer.php" method="post">
                              <input type="hidden" name="id" id="id" value="<?php echo $customer['_id'] ?>">
                              <input type="submit" value="Delete" class="btn btn-outline-danger">
                            </form>
                            <form action="edit_customer.php" method="post">
                              <input type="hidden" name="id" id="id" value="<?php echo $customer['_id'] ?>">
                              <input type="submit" value="Edit" class="btn btn-outline-info">
                            </form>
                          </td>
                        <?php
                          }
                        ?>

                      </tbody>
                    </table>
                    <div>
                    <a>
                      <button class="btn btn-primary" onclick="location.href='add_customer.php'">Add Customer</button>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <button class="btn btn-primary" onclick="location.href='item_data.php'">Item Data</button>
          <button class="btn btn-primary" onclick="location.href='order_data.php'">Order Data</button>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->

        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
</body>

</html>