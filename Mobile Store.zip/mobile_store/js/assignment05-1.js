$(document).ready(function () {
    var addButton = $('.add_button'); //Add button selector
    var wrapper = $('.field_wrapper'); //Input field wrapper
    //Once add button is clicked
    $(addButton).click(function () {
        //Load options using AJAX
        $.ajax({
            url: 'load_items.php',
            type: 'GET',
            dataType: 'html',
            success: function (response) {
                //Add new input field with loaded options
                var fieldHTML = '<div><br><select class="form-control" id="items" name="items[]" placeholder="model" required>' + response + '</select><br><button type="button" class="remove_button btn btn-outline-danger">Remove</button></div>';
                $(wrapper).append(fieldHTML);
            }
        });
    });

    //Once remove button is clicked
    $(wrapper).on('click', '.remove_button', function (e) {
        e.preventDefault();
        $(this).parent('div').remove(); //Remove field html
    });
});
