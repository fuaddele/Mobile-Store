<?php


require_once 'vendor/autoload.php';
// use App\Models\Customer;
use App\Models\MongoDB;

$connection = new MongoDB;

$items = $connection->allitems();

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Phone Store</title>
  <link rel="stylesheet" href="./css/bootstrap.css">
</head>

<body>
  <div class="container-scroller">
    
    <div class="container-fluid page-body-wrapper">
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">

            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Item Table</h4>

                  <p class="card-description">
                  </p>
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>
                            ItemID
                          </th>
                          <th>
                          Manufacturer </th>
                          <th>
                          Model
                          </th>
                          <th>
                          Price

                          </th>
                          <th>
                            Action
                          </th>

                        </tr>

                      </thead>
                      <tbody>
                        <?php 
                          foreach($items as $item){
                        ?>
                        <tr>

                          <td>
                            <?php echo $item['_id'] ?>
                          </td>
                          <td>
                            <?php echo $item['manufacturer'] ?>
                          </td>
                          <td>
                            <?php echo $item['model'] ?>
                          </td>
                          <td>
                            <?php echo $item['price'] ?>
                          </td>

                          <td>
                            <form action="delete_item.php" method="post">
                              <input type="hidden" name="id" id="id" value="<?php echo $item['_id'] ?>">
                              <input type="submit" value="Delete" class="btn btn-outline-danger">
                            </form>
                            <form action="edit_item.php" method="post">
                              <input type="hidden" name="id" id="id" value="<?php echo $item['_id'] ?>">
                              <input type="submit" value="Edit" class="btn btn-outline-info">
                            </form>
                          </td>
                        <?php
                          }
                        ?>

                      </tbody>
                    </table>
                    <div>
                    <a>
                      <button class="btn btn-primary" onclick="location.href='add_item.php'">Add Item</button>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <button class="btn btn-primary" onclick="location.href='customer_data.php'">Customer Data</button>
          <button class="btn btn-primary" onclick="location.href='order_data.php'">Order Data</button>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->

        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
</body>

</html>