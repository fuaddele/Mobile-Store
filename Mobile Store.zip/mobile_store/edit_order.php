<?php

require_once 'vendor/autoload.php';
use App\Models\Order;
use App\Models\MongoDB;

$connection = new MongoDB;
$id = $_POST['id'];
$customers = $connection->allcustomers();
$items = $connection->allitems();
$items = iterator_to_array($items);

$order = $connection->editorder($id);

if(isset($_POST['update'])){
  $newcustomer = $_POST['customer'];
  $newitems = $_POST['items'];

  $o = new Order($newcustomer,$newitems);
  
  $result = $connection->updateorder($id,$o);

  $order = $connection->editorder($id);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Phone Store</title>
  <link rel="stylesheet" href="./css/bootstrap.css">
</head>

<body>
  <div class="container-scroller">
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial -->
      <div class="main-panel">        
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-9 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Order form</h4>
                  <p class="card-description">
                  </p>
                  <form class="forms-sample" method="post" action="edit_order.php">
                  <input type="hidden" name="id" id="id" value="<?php echo $id ?>">
                  <div class="form-group">
                      <label for="exampleInputUsername1">Customer</label>
                      <select class="form-control" id="customer" name="customer" placeholder="manufacturer" required>
                      <?php 
                          foreach($customers as $customer){
                            ?>
                            <option <?php if($order['customer'] == $customer['_id']){ ?> selected <?php } ?>value="<?php echo $customer['_id'] ?>"><?php echo $customer['firstName'].' '.$customer['surname'] ?></option>
                        <?php
                          }
                        ?>  
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Item
                      </label>
                      <?php
                      foreach($order['items'] as $alreadyitems){
                      ?>
                      <select type="text" class="form-control" id="items" name="items[]" placeholder="model" required>
                         <?php 
                          foreach($items as $item){
                            ?>
                            <option <?php if($alreadyitems == $item['_id']){ ?> selected <?php } ?> value="<?php echo $item['_id'] ?>"><?php echo $item['model'] ?></option>
                        <?php
                          }
                        ?>   
                      
                      </select>
                      <?php } ?>
                      
                    </div>
                    <div class="field_wrapper"></div>
                      <button type="button" class="add_button btn btn-outline-success" onclick="add_items()">Add More</button>
                    <button type="submit" class="btn btn-primary me-2" name="update"><a href="order_data.php">Update</button>
                    <button class="btn btn-light">Cancel</button>
                  </form>
                </div>
              </div>
            </div>
            
          </div>
        </div>       
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <script src="./js/assignment05-1.js"></script>
</body>

</html>
