<?php

require_once 'vendor/autoload.php';
use App\Models\Order;
use App\Models\MongoDB;

$connection = new MongoDB;

$customers = $connection->allcustomers();
$items = $connection->allitems();

if(isset($_POST['submit'])){
  $newcustomer = $_POST['customer'];
  $newitems = $_POST['items'];

  $o = new Order($newcustomer , $newitems);

  $result = $connection->add_order($o);

}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Phone Store</title>
  <link rel="stylesheet" href="./css/bootstrap.css">
</head>

<body>
  <div class="container-scroller">
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial -->
      <div class="main-panel">        
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-9 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Order  form</h4>
                  <p class="card-description">
                  </p>
                  <form class="forms-sample" method="post" action="add_order.php">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Customer</label>
                      <select class="form-control" id="customer" name="customer" placeholder="manufacturer" required>
                      <?php 
                          foreach($customers as $customer){
                            ?>
                            <option value="<?php echo $customer['_id'] ?>"><?php echo $customer['firstName'].' '.$customer['surname'] ?></option>
                        <?php
                          }
                        ?>  
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Item
                      </label>
                      <select type="text" class="form-control" id="items" name="items[]" placeholder="model" required>
                         <?php 
                          foreach($items as $item){
                            ?>
                            <option value="<?php echo $item['_id'] ?>"><?php echo $item['model'] ?></option>
                        <?php
                          }
                        ?>   
                      
                      </select>
                      
                    </div>
                    <div class="field_wrapper"></div>
                      <button type="button" class="add_button btn btn-outline-success" onclick="add_items()">Add More</button>
                    <button type="submit" class="btn btn-primary me-2" name="submit"><a href="order_data.php">Submit</button>
                    <button class="btn btn-light">Cancel</button>
                  </form>
                </div>
              </div>
            </div>
            
          </div>
        </div>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <script src="./js/assignment05-2.js"></script>
  </body>
</html>
