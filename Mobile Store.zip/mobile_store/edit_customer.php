<?php

require_once 'vendor/autoload.php';
use App\Models\Customer;
use App\Models\MongoDB;

$connection = new MongoDB;
$id = $_POST['id'];

$customer = $connection->editcustomer($id);

if(isset($_POST['update'])){
  $title = $_POST['title'];
  $fname = $_POST['fname'];
  $sname = $_POST['sname'];
  $mobile = $_POST['mobile'];
  $email = $_POST['email'];
  $homeaddress = $_POST['homeaddress'];
  $shippingaddress = $_POST['shippingaddress'];
  $town = $_POST['town'];
  $country = $_POST['country'];
  $eircode = $_POST['eircode'];

  $c = new Customer($title,$fname,$sname,$mobile,$email,$homeaddress,$shippingaddress,$town,$country,$eircode);

  $result = $connection->updatecustomer($id,$c);

  $customer = $connection->editcustomer($id);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Phone Store</title>
  <link rel="stylesheet" href="./css/bootstrap.css">

</head>

<body>
  <div class="container-scroller">
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial -->
      <div class="main-panel">        
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-9 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Customer  form</h4>
                  <p class="card-description">
                  </p>
                  <form class="forms-sample" method="post" action="edit_customer.php">
                    <div class="form-group">
                    <input type="hidden" name="id" id="id" value="<?php echo $id ?>">
                      <label for="exampleInputUsername1">Title</label>
                      <input type="text" class="form-control" id="title" name="title" placeholder="Title" value="<?php echo $customer['title'] ?>" required>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">First Name
</label>
                      <input type="text" class="form-control" id="fname" name="fname" value="<?php echo $customer['firstName'] ?>" placeholder="name" required>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Surname</label>
                      <input type="text" class="form-control" id="sname" name="sname" value="<?php echo $customer['surname'] ?>" placeholder="Surname" required>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputConfirmPassword1">Mobile</label>
                      <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo $customer['mobile'] ?>" placeholder="mobile" required>
                    </div>
                     <div class="form-group">
                      <label for="exampleInputConfirmPassword1">Email Address
</label>
                      <input type="text" class="form-control" id="email" name="email" value="<?php echo $customer['email'] ?>" placeholder="email" required>
                    </div>
                     <div class="form-group">
                      <label for="exampleInputConfirmPassword1">Home Address </label>
                      <input type="text" class="form-control" id="homeaddress" name="homeaddress" value="<?php echo $customer['homeaddress'] ?>" required placeholder="Home Address ID">
                    </div>
                     <div class="form-group">
                      <label for="exampleInputConfirmPassword1">Shipping Address</label>
                      <input type="text" class="form-control" id="shippingaddress" name="shippingaddress" value="<?php echo $customer['shippingaddress'] ?>" required placeholder="Shipping Address">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputConfirmPassword1">Town</label>
                      <input type="text" class="form-control" id="town" name="town" value="<?php echo $customer['town'] ?>" required placeholder="Town">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputConfirmPassword1">Country</label>
                      <input type="text" class="form-control" id="country" name="country" value="<?php echo $customer['country'] ?>" required placeholder="Country">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputConfirmPassword1">Eircode</label>
                      <input type="text" class="form-control" id="eircode" name="eircode" value="<?php echo $customer['eircode'] ?>" required placeholder="Eircode">
                    </div>                    
                    <button type="submit" class="btn btn-primary me-2" name="update"><a href="customer_data.php">Update</button>
                    <button class="btn btn-light">Cancel</button>
                  </form>
                </div>
              </div>
            </div>
            
          </div>
        </div>       
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
</body>

</html>
