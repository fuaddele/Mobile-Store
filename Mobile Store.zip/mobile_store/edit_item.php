<?php

require_once 'vendor/autoload.php';
use App\Models\Item;
use App\Models\MongoDB;

$connection = new MongoDB;
$id = $_POST['id'];

$item = $connection->edititem($id);

if(isset($_POST['update'])){
  $manufacturer = $_POST['manufacturer'];
  $model = $_POST['model'];
  $price = $_POST['price'];

  $i = new Item($manufacturer,$model,$price);
  
  $result = $connection->updateitem($id,$i);

  $item = $connection->edititem($id);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Phone Store</title>
  <link rel="stylesheet" href="./css/bootstrap.css">

</head>

<body>
  <div class="container-scroller">
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial -->
      <div class="main-panel">        
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-9 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Item form</h4>
                  <p class="card-description">
                  </p>
                  <form class="forms-sample" method="post" action="edit_item.php">
                    <div class="form-group">
                    <input type="hidden" name="id" id="id" value="<?php echo $id ?>">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Manufacturer</label>
                      <input type="text" value="<?php echo $item['manufacturer'] ?>" class="form-control" id="manufacturer" name="manufacturer" placeholder="manufacturer" required>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Model
</label>
                      <input type="text" class="form-control" value="<?php echo $item['model'] ?>" id="model" name="model" placeholder="model" required>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Price</label>
                      <input type="text" class="form-control" value="<?php echo $item['price'] ?>" id="price" name="price" placeholder="price" required>
                    </div>
                    <button type="submit" class="btn btn-primary me-2" name="update"><a href="item_data.php">Update</button>
                    <button class="btn btn-light">Cancel</button>
                  </form>
                </div>
              </div>
            </div>
            
          </div>
        </div>
       
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
</body>

</html>
